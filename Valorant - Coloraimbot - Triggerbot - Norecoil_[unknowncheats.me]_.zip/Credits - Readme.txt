Credits for the Aimbot Source to Voluminoso: https://www.unknowncheats.me/forum/valorant/386802-color-aimbot.html
Credits for the Triggerbot Source to jamz256: https://www.unknowncheats.me/forum/valorant/388588-ahk-triggerbot.html
Credits for the NoRecoil Source to KratosHaynes: https://www.unknowncheats.me/forum/valorant/387832-valorant-recoil-ahk.html

*Recoded* by Baseult